layui.use('all', function(){
	const util = layui.util;
	const table = layui.table;
	const exportToExcel = async (fileName, contacts, type = "excel") => {
		const workbook = new ExcelJS.Workbook();
		const worksheet = workbook.addWorksheet("Sheet1");
		if(type === 'whatsapp'){
			worksheet.addRow(["Phone Number", "Formatted Phone", "Name", "Formatted Name", "Server"]);
			for (const index in contacts) {
				const contact = contacts[index];
				worksheet.addRow([contact.phone_number, contact.formatted_phone, contact.name ?? '', contact.formatted_name ?? '', contact.server]);
			}
		}else {
			worksheet.addRow(["Name", "Avatar", "Exists"]);
			for (const index in contacts) {
				const contact = contacts[index];
				worksheet.addRow([contact.name, contact.avatar, contact.exists ?? '']);
			}
		}
	
		const buffer = await workbook.xlsx.writeBuffer();
		const blob = new Blob([buffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
		saveAs(blob, `${fileName}.xlsx`);
	};
	let zaloContacts = [];
	let whatsappContacts = [];
	util.on('lay-on', {
		'getZaloContacts': function(){
			chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
				const currentTab = tabs[0];
				if(currentTab.url.indexOf("https://chat.zalo.me/") === -1){
					alert("Vui lòng truy website: https://chat.zalo.me/");
				}else{
					chrome.tabs.sendMessage(currentTab.id, {type: "zalo"});
				}
			});
		},
		'downloadContactsZalo': () => {
			exportToExcel("zalo-contacts", zaloContacts);
		},
		'getWhatsappContacts': async function(){
			chrome.tabs.query({active: true, currentWindow: true}, async function(tabs) {
				const currentTab = tabs[0];
				if(currentTab.url.indexOf("https://web.whatsapp.com/") === -1){
					alert(`Vui lòng truy website: https://web.whatsapp.com/`);
				}else{

					// chrome.scripting.executeScript({
					// 	target: {tabId: currentTab.id, allFrames: true},
					// 	files: ['/assets/wa.js']
					// });
					// WPP.webpack.onReady(function () {
					// 	alert('Ready to use WPPConnect WA-JS');
					// });
					chrome.tabs.sendMessage(currentTab.id, {type: "whatsapp"});
				}
			});
		},
		'downloadContactsWhatsapp': () => {
			exportToExcel("whatsapp-contacts", whatsappContacts, 'whatsapp');
		},
	});
	chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
		if(message.type == "zalo"){
			const zaloResultWrapId = "#zalo-contact-result";
			const tableContactExistsId = "#zalo-contact-exists";
			$(`${zaloResultWrapId}`).removeClass("layui-hide");
			$(`${zaloResultWrapId}`).find('.total').text(message.total);
			$(`${zaloResultWrapId}`).find('.num-of-result').text(((message.contacts ?? []).length - 1));
			zaloContacts = message.contacts ?? [];
			if((message.exists ?? []).length > 0){
				$(`${tableContactExistsId}`).removeClass("layui-hide");
				let html = "";
				for(contact of message.exists){
					html += "<tr>";
					html += `<td>${contact.name}</td>`;
					html += `<td style="text-align: right;">${contact.exists}</td>`
					html += "</tr>";
				}
				$(`${tableContactExistsId}`).find('tbody').html(html);
			}
			// const zaloContactExistsTable = table.render({
			// 	elem: "#zalo-contact-exists",
			// 	cols: [[
			// 		{field: 'name', title: "Tên", sort: true},
			// 		{field: 'exists', title: "Số liên hệ trùng lặp", sort: true},
			// 	]],
			// 	data: message.contacts ?? []
			// });
		}else if(message.type == 'whatsapp'){
			const whatsappResultWrapId = "#whatsapp-contact-result";
			const tableContactExistsId = "#whatsapp-contact-exists";
			$(`${whatsappResultWrapId}`).removeClass("layui-hide");
			$(`${whatsappResultWrapId}`).find('.total').text(message.total);
			$(`${whatsappResultWrapId}`).find('.num-of-result').text(((message.contacts ?? []).length));
			whatsappContacts = message.contacts ?? [];
		}
		// Xử lý tin nhắn ở đây
	});
});