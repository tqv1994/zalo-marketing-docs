const sleep = (delay) => new Promise((resolve) => setTimeout(resolve, delay));

function getElementByXPath(path) {
    return (new XPathEvaluator())
        .evaluate(path, document.documentElement, null,
            XPathResult.FIRST_ORDERED_NODE_TYPE, null)
        .singleNodeValue;
}

function getElementsByXPath(path) {
    const result = (new XPathEvaluator()).evaluate(path, document.documentElement, null, XPathResult.ANY_TYPE, null);
    const nodes = [];
    let node;
    while (node = result.iterateNext()) {
        nodes.push(node);
    }
    return nodes;
}

getContactList = (contacts = []) => {
    const contactGroups = getElementsByXPath("//*[@id='container']/div[3]/div[2]/div/div[1]/div/div[1]/div/div/div");
    for (const index in contactGroups) {
        try {
            let node = contactGroups[index];
            contactWrapNode = node.querySelector(".contact-item-v2-wrapper");
            detailInfoNode = contactWrapNode.querySelector(".detail-info");
            contactNameNode = detailInfoNode.querySelector('.name');
            contactAvatar = contactWrapNode.querySelector('.zavatar img')?.getAttribute("src") ?? "";
            let isExist = false;
            for (const index in contacts) {
                const contact = contacts[index];
                if (contact.name === contactNameNode.textContent.trim()) {
                    if (contact.avatar !== contactAvatar) {
                        if ((contact.avatarExists ?? []).length > 0) {
                            let isExistAvatar = false;
                            for (const avatar of contact.avatarExists) {
                                if (avatar === contactAvatar) {
                                    isExistAvatar = true;
                                    break;
                                }
                            }
                            if (isExistAvatar === false) {
                                contact.avatarExists.push(contactAvatar);
                                contact.exists = (contact.exists ?? 0) + 1;
                            }
                        } else {
                            contact.avatarExists.push(contactAvatar);
                            contact.exists = (contact.exists ?? 0) + 1;
                        }
                    }
                    isExist = true;
                    break;
                }
            }

            if (isExist === false) {
                contacts.push({ name: contactNameNode.textContent.trim(), avatar: contactAvatar, avatarExists: [] });
            }
        } catch (e) {
            continue;
        }
    }
    return contacts;
}

const handleScrollContactList = (startHeight) => {
    const wrapScrollNode = document.querySelector(".contact-tab-v2__scrollbar-custom > div");
    wrapScrollNode.scrollTo(wrapScrollNode.offsetHeight * startHeight, wrapScrollNode.offsetHeight * (startHeight + 1) - wrapScrollNode.offsetHeight * 1/4);
}

const returnPopupResults = (contacts, total) => {
    exists = [];
    for (const contact of contacts) {
        if (contact.exists && contact.exists > 0) {
            exists.push({ name: contact.name, exists: contact.exists });
        }
    }

    chrome.runtime.sendMessage({ contacts, type: 'zalo', exists, total });
}

const handleZaloPage = async () => {
    try {
        let count = 0;
        let contacts = [{ name: "Cloud của tôi", avatar: "https://res-zalo.zadn.vn/upload/media/2021/6/4/2_1622800570007_369788.jpg" }];
        getElementByXPath("//div[@data-translate-title='STR_TAB_CONTACT']").click();
        await sleep(10);
        getElementByXPath('//*[@id="ContactTabV2"]/div/div[1]').click();
        await sleep(10);
        document.querySelector(".contact-tab-v2__scrollbar-custom > div").scrollTo(0, 0);
        await sleep(20);
        const totalStr = document.querySelector("[data-translate-inner=STR_FRIEND_LIST_COUNTER]").textContent.trim();
        const total = parseInt(totalStr.replace(/[^\d]/g, "")) ?? 0;
        let firstHeight = document.querySelector(".contact-tab-v2__scrollbar-custom div.ReactVirtualized__Grid__innerScrollContainer").scrollHeight;
        while (true) {
                contacts = getContactList(contacts);
                await sleep(100);
                handleScrollContactList(count);
                await sleep(100);
                let lastHeight = document.querySelector(".contact-tab-v2__scrollbar-custom div.ReactVirtualized__Grid__innerScrollContainer").scrollHeight;
                await sleep(100);
                if (firstHeight === lastHeight) break;
                firstHeight = lastHeight;
            count++;
        }
        //exportToExcel("zalo-contacts", contacts);
        returnPopupResults(contacts, total);
    } catch (e) {
        console.log(e);
    }
}

const handleWhatsappPage = async () => {
    try{
        // console.log(WPP.contact.get());
        const res = await WPP.contact.list();
        console.log(res);
    }catch (e){
        console.log(e);
    }
}

function injectScript (src) {
    const s = document.createElement('script');
    s.src = chrome.runtime.getURL(src);
    s.onload = () => s.remove();
    (document.body || document.documentElement).append(s);
}

chrome.runtime.onMessage.addListener(async function (message, sender, sendResponse) {
    if (message.type === "zalo") {
        handleZaloPage();
    }else if(message.type == 'whatsapp'){
        localStorage.setItem("HANDLE_GET_WHATSAPP_CONTACT", true);
        injectScript('assets/wa.js');
        injectScript('assets/inject.js');
        while (true){
            if(JSON.parse(localStorage.getItem('HANDLE_GET_WHATSAPP_CONTACT')) == null){
                contacts = JSON.parse(localStorage.getItem('WHATSAPP_CONTACTS'));
                localStorage.removeItem('WHATSAPP_CONTACTS');
                chrome.runtime.sendMessage({ contacts, type: 'whatsapp', total: contacts.length });
                break;
            }
            await sleep(100);
        }
        //await sleep(20);
        //await handleWhatsappPage();
    }
});

