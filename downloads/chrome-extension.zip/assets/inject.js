(function () {
    'use strict';

    WPP.webpack.onReady(async function () {
        try {
            //alert('Ready to use WPPConnect WA-JS');
            const res = await WPP.contact.list();
            const data = res.filter((contact) => contact.isUser && contact.isMyContact && !contact.__x_phoneNumber);
            const result = [];
            for (const i in data) {
                const contact = data[i];
                result.push({
                    phone_number: contact.userid,
                    formatted_phone: contact.formattedPhone,
                    name: contact.name,
                    formatted_name: contact.formattedName,
                    server: contact.__x_id.server
                });
            }
            localStorage.setItem('WHATSAPP_CONTACTS', JSON.stringify(result));
            localStorage.removeItem('HANDLE_GET_WHATSAPP_CONTACT');

        } catch (e){
            localStorage.removeItem('HANDLE_GET_WHATSAPP_CONTACT');
            console.log(e);
        }
    });

    // Your code here...
})();